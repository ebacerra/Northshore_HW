# NorthShore Interview Homework

================================

### Overview

Redesigned one of their landing page in a week. -
_Semi-finished due to a lot of content information needed to be added_

### Kellogg Cancer Center - https://www.northshore.org/kellogg-cancer-center/
